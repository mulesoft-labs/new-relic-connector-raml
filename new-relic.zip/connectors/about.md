Configuring connector

- In order to run this connector you will need a NewRelic account.
- In the "Integrations/Data Sharing" tab inside your account settings you must enable API access. In your request you must pass API Key as 'X-Api-Key' header value. API Key can be found in the same "Integrations/Data Sharing" tab.


Running connector

- Make a call on the http://localhost:8081/newrelic URL.